import SwiftUI

struct ViewHome: View {
    @State private var showPopup: Bool = false
    @State private var fullscreenImageIndex: Int? = nil
    
    let images = [
        "app1", "app2", "app3", "app4", "app5", "app6"
    ]
    
    let imageTexts = [
        "1. Eine App über Apps\nDas ist ein Designprozess, der dich von der Ideenfindung bis zur Erstellung von App-Prototypen führt und schließlich zu einer fertigen App. Dieser Info-Button gibt dir einen Überblick über den Inhalt der App.",
        "2. Zeichnen\nUnter dem Reiter Zeichnen kannst du mit den eingebauten Werkzeugen Skizzen machen und deine Ideen erklären, sowie Layouts entwickeln. Klicke auf 'Ideenfindung', um 8 App-Ideen zu skizzieren, aus denen du später die beste auswählen kannst. Unter 'Leer', 'iPhone' und 'iPad' kannst du Layouts für deine App in verschiedenen Formaten entwerfen.",
        "3. Freeform\nWenn du auf Freeform klickst, kannst du eine Mindmap in Freeform herunterladen, um all deine Ideen zu verbinden. In der Mindmap kannst du verschiedene Arten von Buttons, iPhone-Rahmen und Notizzetteln in deinen Arbeitsbereich ziehen. Wenn du möchtest, kannst du auch eine traditionelle Mindmap auf Papier erstellen.",
        "4. Materialien\nUnter Materialien kannst du Keynote-Materialien herunterladen, um Prototypen für deine App zu entwickeln, egal ob für Apple Watch, iPhone, iPad oder MacBook. Jedes Keynote-Design ist einzigartig und bietet verschiedene Vorlagen für deine Layouts. Außerdem kannst du Lehrmaterialien für das Projekt sowie Aktivitäten für Schüler herunterladen. Wenn du möchtest, kannst du auch spezielles Lehrmaterial zum Programmieren in Swift herunterladen.",
        "5. Apps\nUnter dem Reiter Apps kannst du lernen, wie du mit dem Programmieren in Swift beginnst. Hier kannst du die Apple-Materialien 'Get Started with Code' und 'About Me' erkunden. Speziell für 'Eine App über Apps' kannst du 4 Apps herunterladen, in denen du lernst, wie man Navigationsleisten (Menüs), Stack Views (Anordnung von Objekten), Inhalte einfügt (Text, Bilder, Videos und Links hinzufügt) und Dinge zum Starten (verschiedene nützliche Funktionen) erstellt.",
        "6. Portfolio\nIm Abschnitt Portfolio kannst du deine Reise von der Idee über das Layout, das Feedback und die Prototypen bis hin zur fertigen App aktualisieren und dokumentieren. Im Portfolio kannst du Fotos aus deinem Kamerarollen hochladen und deine Erfahrungen mit Text beschreiben. Unten im Portfolio kannst du weitere Bild- und Textfelder hinzufügen."
    ]
    
    var body: some View {
        ZStack {
            LinearGradient(
                gradient: Gradient(colors: [
                    Color(red: 217 / 255, green: 201 / 255, blue: 254 / 255),
                    Color(red: 86 / 255, green: 193 / 255, blue: 255 / 255)
                ]),
                startPoint: .leading,
                endPoint: .trailing
            )
            .edgesIgnoringSafeArea(.all)
            
            GeometryReader { geometry in
                
                let imageSize = geometry.size.width / 10.65
                
                VStack(alignment: .center, spacing: 30) {
                    Text("An App About Apps")
                        .font(.system(size: 50, weight: .bold))
                        .foregroundColor(Color(red: 255 / 255, green: 150 / 255, blue: 141 / 255))
                        .padding(.top, 60)
                        .frame(maxWidth: 600)
                    
                    Image("LOGO")
                        .resizable()
                        .aspectRatio(2.4/1, contentMode: .fit)
                        .padding(.horizontal, imageSize)
                        .foregroundColor(Color(red: 1, green: 0.5, blue: 0))
                        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .center)
                        .padding(-30)
                    
                    
                    Text("An App About Apps hilft dir, von der Ideenentwicklung über das Skizzieren und Beschreiben dieser Ideen bis hin zur Erstellung von App-Prototypen zu gelangen. Wenn du möchtest, kannst du auch das Programmieren in Swift lernen, damit du irgendwann eine echte App im App Store veröffentlichen kannst. Verwirkliche deine Visionen und Ideen! Klicke auf den Info-Button, um einen Überblick über die verschiedenen Abschnitte der App zu erhalten.")

                        .font(.system(size: 20, weight: .regular)) 
                        .foregroundColor(Color(red: 1, green: 0.5, blue: 0)) 
                        .frame(maxWidth: 800)
                        .multilineTextAlignment(.center)
                    
                    Text("Klicke auf den Info-Button, um einen Überblick über die verschiedenen Abschnitte der App zu erhalten.")
                        .font(.system(size: 20, weight: .regular)) 
                        .foregroundColor(Color(red: 1, green: 0.5, blue: 0)) 
                        .frame(maxWidth: 800)
                        .multilineTextAlignment(.center)
                    
                    
                }
                .padding(.bottom, 100)
                
                Spacer()
                
                    .padding()
                
                VStack {
                    Spacer()
                    
                    HStack {
                        Spacer()
                        
                        Button(action: {
                            showPopup.toggle()
                        }) {
                            Image(systemName: "info.circle")
                                .font(.largeTitle)
                                .padding()
                                .foregroundColor(.black)
                                .clipShape(Circle())
                        }
                        .padding(.trailing, 20)
                        .padding(.bottom, 20)
                    }
                }
                
                if showPopup {
                    PopupView2(showPopup: $showPopup, images: images, imageTexts: imageTexts, fullscreenImageIndex: $fullscreenImageIndex)
                        .transition(.scale)
                        .zIndex(1)
                }
                
                if let index = fullscreenImageIndex {
                    FullScreenImageView(images: images, imageTexts: imageTexts, currentIndex: index, fullscreenImageIndex: $fullscreenImageIndex)
                        .zIndex(2)
                }
            }
        }
    }
}
struct PopupView2: View {
    @Binding var showPopup: Bool
    let images: [String]
    let imageTexts: [String]
    @State private var currentPage: Int = 0
    @Binding var fullscreenImageIndex: Int?
    
    var body: some View {
        VStack(spacing: 20) {
            Text("Was ist eine App über Apps?")
                .font(.headline)
                .padding()
            
            TabView(selection: $currentPage) {
                ForEach(0..<images.count, id: \.self) { index in
                    VStack {
                        Image(images[index])
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .frame(width: 400, height: 300)
                            .onTapGesture {
                                fullscreenImageIndex = index
                            }
                        
                        Text(imageTexts[index])
                            .font(.body)
                            .multilineTextAlignment(.center)
                            .padding()
                            .background(Color.white)
                            .cornerRadius(10)
                            .foregroundColor(.black)
                            .frame(maxWidth: .infinity, maxHeight: 200)  
                            .fixedSize(horizontal: false, vertical: true)
                    }
                    .tag(index)
                }
            }
            .tabViewStyle(PageTabViewStyle())
            .frame(width: 600, height: 400)
            
            Text("\(currentPage + 1) of \(images.count)")
                .font(.footnote)
                .padding(-10)
            
            Button(action: {
                showPopup = false
            }) {
                Image(systemName: "xmark.circle")
                    .font(.title2)
                    .padding()
                    .foregroundColor(.black)
                    .cornerRadius(10)
            }
        }
        .frame(width: 600, height: 600)
        .background(Color.white)
        .cornerRadius(20)
        .shadow(radius: 20)
        .padding()
    }
}
struct FullScreenImageView: View {
    let images: [String]
    let imageTexts: [String]
    @State var currentIndex: Int
    @Binding var fullscreenImageIndex: Int?
    
    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()
            
            VStack {
                Spacer()
                
                TabView(selection: $currentIndex) {
                    ForEach(0..<images.count, id: \.self) { index in
                        Image(images[index])
                            .resizable()
                            .scaledToFit()
                            .frame(maxWidth: .infinity, maxHeight: .infinity)
                            .onTapGesture {
                                fullscreenImageIndex = nil
                            }
                            .padding()
                            .tag(index)
                    }
                }
                .tabViewStyle(PageTabViewStyle())
                .indexViewStyle(PageIndexViewStyle())
                
                Text(imageTexts[currentIndex])
                    .padding()
                    .background(
                        RoundedRectangle(cornerRadius: 10)
                            .fill(Color.white)
                            .overlay(
                                RoundedRectangle(cornerRadius: 10)
                                    .stroke(Color.black, lineWidth: 1)
                            )
                    )
                    .padding()
                    .foregroundColor(.black)
                    .multilineTextAlignment(.center)
                
                Text("\(currentIndex + 1) of \(images.count)")
                    .font(.footnote)
                    .padding(.bottom, 10)
                
                Spacer()
            }
        }
    }
}

struct ViewHome_Previews: PreviewProvider {
    static var previews: some View {
        ViewHome()
    }
}

