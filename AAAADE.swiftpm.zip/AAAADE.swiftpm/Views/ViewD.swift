import SwiftUI

struct ViewD: View {
    
    
    let columns = [
        GridItem(.flexible()),
        GridItem(.flexible())
    ]
    
    var body: some View {
        ZStack {
            LinearGradient(
                gradient: Gradient(colors: [
                    Color(red: 217 / 255, green: 201 / 255, blue: 254 / 255),
                    Color(red: 86 / 255, green: 193 / 255, blue: 255 / 255)
                ]),
                startPoint: .leading,
                endPoint: .trailing
            )
            .edgesIgnoringSafeArea(.all)
            
            VStack {
               
                VStack {
                    Text("Apps, die du als Bausteine und Inspiration nutzen kannst")
                        .font(.title)
                        .foregroundColor(.black)
                        .fontWeight(.bold)
                        .padding(.bottom, 5)
                    
                    Text("Auf dieser Seite musst du beschreiben, was in deine App aufgenommen werden soll, wie sie aussehen soll und warum. Diese Arbeit sollte in einem Whiteboard-Dokument in Freeform zusammengefasst werden. Wir haben eine Vorlage für dich erstellt. Du kannst sie herunterladen, indem du unten auf das Freeform-App-Symbol klickst. Sobald du das Dokument heruntergeladen hast, musst du es duplizieren. Erfahre mehr darüber im Info-Button auf dieser Seite.")

                        .font(.subheadline)
                        .foregroundColor(.black)
                        .multilineTextAlignment(.center)
                        .padding(.horizontal)
                        .lineLimit(10) 
                        .minimumScaleFactor(0.5) 
                        .padding(.bottom, 20)
                }
                
                ScrollView {
                    LazyVGrid(columns: columns, spacing: 20) {
                        contentBox(title: "Starte mit dem Code", description: "Ein großartiger Ort, um deine Programmierreise zu beginnen.", linkURL: "")
                        
                        contentBox(title: "Über mich", description: "Erstelle ein Projekt über dich selbst und lerne, wie du beim Bauen deiner ersten App programmierst.", linkURL: "")
                        
                        contentBox(title: "Erstelle eine Navigationsleiste", description: "Lerne, wie man ein Menü mit drei oder mehr Buttons erstellt. Diese App ist in deinem Abonnement für 'Eine App über Apps' auf der Swift-Homepage enthalten. Scrolle nach unten und finde die Navigationsleiste-App.", linkURL: "https://appsbyralo.github.io/An-App-About-Apps/index.html")
                        
                        contentBox(title: "Stack Views", description: "Lerne, wie man Objekte horizontal, vertikal und entlang der Z-Achse positioniert oder die verschiedenen Optionen kombiniert. Diese App ist in deinem Abonnement für 'Eine App über Apps' auf der Swift-Homepage enthalten. Scrolle nach unten und finde die Stack Views-App.", linkURL: "https://appsbyralo.github.io/An-App-About-Apps/index.html")
                        
                        contentBox(title: "Inhalte einfügen", description: "Lerne, wie man Fotos, Videos und Links in deine App einfügt. Diese App ist in deinem Abonnement für 'Eine App über Apps' auf der Swift-Homepage enthalten. Scrolle nach unten und finde die Inhalte einfügen-App.", linkURL: "https://appsbyralo.github.io/An-App-About-Apps/index.html")
                        
                        contentBox(title: "Dinge, die dir den Start erleichtern", description: "Dies ist eine App mit verschiedenen Ideen, wie GPS-Karten von Apple Maps und verschiedene Arten von Buttons, die zusammen deine App einzigartig machen können. Diese App ist in deinem Abonnement für 'Eine App über Apps' auf der Swift-Homepage enthalten. Scrolle nach unten und finde die Dinge, die dir den Start erleichtern-App.", linkURL: "https://appsbyralo.github.io/An-App-About-Apps/index.html")
                    }
                    .padding()
                }
            }
        }
    }
    
    @ViewBuilder
    private func contentBox(title: String, description: String, linkURL: String, actionURL: String? = nil) -> some View {
        VStack(alignment: .leading) {
            Text(title)
                .font(.title2)
                .fontWeight(.bold)
                .lineLimit(2)
                .minimumScaleFactor(0.5)
                .foregroundColor(.black) 
            
            Divider()  
            
            Text(description)
                .font(.subheadline)
                .foregroundColor(.black) 
            
            Text("Link")
                .font(.subheadline)
                .foregroundColor(.blue)
                .underline()
                .onTapGesture {
                    if let url = URL(string: linkURL) {
                        UIApplication.shared.open(url)
                    }
                }
        }
        .padding()
        .background(Color.white)
        .cornerRadius(15)
        .shadow(radius: 5)
        .frame(height: 200)  
        .padding(.horizontal)
        .onTapGesture {
            if let urlString = actionURL, let url = URL(string: urlString) {
                UIApplication.shared.open(url)
            }
        }
    }
}

struct ViewD_Previews: PreviewProvider {
    static var previews: some View {
        ViewD()
    }
}

