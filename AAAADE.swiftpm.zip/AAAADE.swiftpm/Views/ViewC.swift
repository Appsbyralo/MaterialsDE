import SwiftUI

struct ViewC: View {
    @State private var showPopup: Bool = false
    @State private var fullscreenImageIndex: Int? = nil
    
    let columns = [
        GridItem(.flexible()),
        GridItem(.flexible())
    ]
    
    let images = [
        "keynote1", "keynote2", "keynote3", "keynote4", "keynote5", "keynote6", "keynote7"
    ] + [
        "shortcuts", "shortcut1", "shortcut2", "shortcut3", "shortcut4", "shortcut5", "shortcut6", "shortcut7"
    ]
    
    @State private var imageTexts = [
        "1. Hier kannst du den Ideenkompass herunterladen, um deine beste Idee auszuwählen. Du kannst auch AppGPT, einen Chatbot, der dir bei der Entwicklung deiner App-Idee hilft, eine One Pager-Präsentation zum Vorstellen deiner App-Idee und eine Analyse deiner Lieblings-App herunterladen.",
        "2. iPad-Prototyp-App in Keynote\nIn dieser Keynote-Datei erhältst du ein maßgeschneidertes Keynote-Thema, um deine Prototyp-App für ein iPad zu entwickeln. Indem du auf + klickst, um eine neue Folie hinzuzufügen, kannst du aus einer Vielzahl von Layouts wählen, um deine Ideen am besten darzustellen.",
        "3. iPhone-Prototyp-App in Keynote\nIn dieser Keynote-Datei erhältst du ein angepasstes Keynote-Thema, um deine Prototyp-App für ein iPhone zu entwickeln. Indem du auf + klickst, um eine neue Folie hinzuzufügen, kannst du aus verschiedenen Layouts wählen, um deine Ideen effektiv zu vermitteln.",
        "4. MacBook-Prototyp-App in Keynote\nIn dieser Keynote-Datei erhältst du ein spezielles Keynote-Thema, um deine Prototyp-App für ein MacBook zu erstellen. Durch Drücken auf +, um eine neue Folie hinzuzufügen, kannst du aus verschiedenen Layouts wählen, um deine Ideen klar zu präsentieren.",
        "5. Apple Watch-Prototyp-App in Keynote\nIn dieser Keynote-Datei erhältst du ein einzigartiges Keynote-Thema, um deine Prototyp-App für eine Apple Watch zu gestalten. Durch Drücken auf +, um eine neue Folie hinzuzufügen, kannst du aus verschiedenen Layouts wählen, um deine Ideen effizient zu vermitteln.",
        "6. Lehrmaterialien\nIn Lehrmaterialien erhältst du Ressourcen, die dir als Lehrer helfen, das Projekt 'Eine App über Apps' selbstbewusst zu starten. Du kannst ein Keynote-Buch herunterladen, das dich durch alle Schritte von der Idee bis zur Prototyp-App führt.",
        "7. Lehrmaterialien in Swift\nZusätzlich kannst du ein Keynote-Buch herunterladen, das sich darauf konzentriert, mit dem Programmieren in Swift zu beginnen und die Apps unter dem Reiter 'Apps' in deinem Unterricht zu unterstützen.",
        "Erstelle eine Verknüpfung für deine App",
        "1. Öffne die Shortcuts-App auf deinem iPad.",
        "2. Drücke auf das \"+\", um eine neue Verknüpfung zu deinem Home-Bildschirm zu erstellen.",
        "3. Suche im Suchfeld nach Keynote. Wähle nun die Verknüpfung 'Präsentation im Viewer-Modus abspielen' aus.",
        "4. Drücke auf die Keynote-Präsentation, um die Datei auszuwählen, die geöffnet wird, wenn die Verknüpfung gedrückt wird.",
        "5. Drücke nun auf den Pfeil und benenne deine Verknüpfung, indem du auf 'Umbenennen' drückst. Wähle ein Symbol für die Verknüpfung und drücke schließlich auf 'Zum Home-Bildschirm hinzufügen'.",
        "6. Drücke auf 'Hinzufügen', um die Verknüpfung zum Home-Bildschirm hinzuzufügen.",
        "7. Du hast jetzt eine Verknüpfung zu deinem Home-Bildschirm erstellt."
    ]
    
    var body: some View {
        ZStack {
            LinearGradient(
                gradient: Gradient(colors: [
                    Color(red: 217 / 255, green: 201 / 255, blue: 254 / 255),
                    Color(red: 86 / 255, green: 193 / 255, blue: 255 / 255)
                ]),
                startPoint: .leading,
                endPoint: .trailing
            )
            .edgesIgnoringSafeArea(.all)
            
            VStack {
                VStack {
                    Text("Erstelle einen Prototyp mit Seitenwechsel-Buttons")
                        .font(.title)
                        .foregroundColor(.black)
                        .fontWeight(.bold)
                        .padding(.bottom, 5)
                    
                   Text("Auf dieser Seite kannst du Schüler-Materialien herunterladen, um deine App-Ideen zu analysieren und die beste auszuwählen. Außerdem kannst du Materialien herunterladen, um mit deiner Lieblings-App zu arbeiten, eine One Pager-Präsentation zu erstellen und AppGPT herunterzuladen, einen Chatbot, der deine App-Idee hinterfragt. Außerdem kannst du App-Prototyp-Dateien in Keynote herunterladen, die für Apps auf iPad, iPhone, MacBook und Apple Watch entworfen wurden. Als Lehrer kannst du auch Lehrmaterialien herunterladen, einschließlich Ressourcen, um das Unterrichtsprojekt zu erleichtern und Materialien, die sich auf das Programmieren in Swift konzentrieren.")
                         
                        
                        .font(.subheadline)
                        .foregroundColor(.black)
                        .multilineTextAlignment(.center)
                        .padding(.horizontal)
                        .lineLimit(10)
                        .minimumScaleFactor(0.5)
                        .padding(.bottom, 20)
                }
                
                ScrollView {
                    LazyVGrid(columns: columns, spacing: 20) {
                        contentBox(title: "Schülermaterialien", description: "Klicke hier, um den Ideenkompass, AppGPT, Meine Lieblings-App und die One Pager-Präsentation herunterzuladen.", linkURL: "https://appsbyralo.github.io/An-App-About-Apps/index.html")
                        
                        contentBox(title: "App-Prototyp iPad", description: "Klicke hier, um die Keynote-Datei für den iPad-Prototyp herunterzuladen. Entwickle deine Ideen nahtlos.", linkURL: "https://raw.githubusercontent.com/Appsbyralo/materialsEN/main/Keynote%20prototype%20app%20iPad.key")
                        
                        contentBox(title: "App-Prototyp iPhone", description: "Klicke hier, um die Keynote-Datei für den iPhone-Prototyp herunterzuladen. Erwecke deine App-Ideen zum Leben.", linkURL: "https://raw.githubusercontent.com/Appsbyralo/materialsEN/main/Keynote%20prototype%20iPhone.key.zip")
                        
                        contentBox(title: "App-Prototyp Mac", description: "Klicke hier, um die Keynote-Datei für den Mac-Prototyp herunterzuladen. Entwirf und verfeinere deine Konzepte.", linkURL: "https://raw.githubusercontent.com/Appsbyralo/materialsEN/main/Keynote%20prototype%20app%20MacBook.key.zip")
                        
                        contentBox(title: "App-Prototyp Apple Watch", description: "Klicke hier, um die Keynote-Datei für den Watch-Prototyp herunterzuladen. Innoviere und visualisiere deine App.", linkURL: "https://raw.githubusercontent.com/Appsbyralo/materialsEN/main/Keynote%20prototype%20Apple%20Watch.key")
                        
                        contentBox(title: "Lehrmaterial", description: "Ein umfassender Leitfaden zu 'Eine App über Apps'. Lade Keynote-Bücher herunter, um dir den Einstieg zu erleichtern und das Programmieren in Swift zu unterrichten.", linkURL: "https://app.box.com/s/b6a1m1jguxyx5fp6a476tbo0tfcn6gjf")
                        
                        contentBox(title: "Lehrmaterialien in Swift", description: "Zusätzlich kannst du ein Keynote-Buch herunterladen, das sich darauf konzentriert, mit dem Programmieren in Swift zu beginnen und die Apps unter dem Reiter 'Apps' im Unterricht zu unterstützen.", linkURL: "https://app.box.com/s/76jghz4hifyu5e4uh8egap5jk21ocwj5")
                    }
                    .padding()
                }
                
                Spacer()
                
                HStack {
                    Spacer()
                    Button(action: {
                        withAnimation {
                            showPopup.toggle()
                        }
                    }) {
                        Image(systemName: "info.circle")
                            .font(.largeTitle)
                            .padding()
                            .foregroundColor(.black)
                            .clipShape(Circle())
                    }
                    .padding(.trailing, 20)
                    .padding(.bottom, 20)
                }
            }
            
            if showPopup {
                PopupView3(showPopup: $showPopup, images: images, imageTexts: $imageTexts, fullscreenImageIndex: $fullscreenImageIndex)
                    .transition(.scale)
                    .zIndex(1)
            }
            
            if let index = fullscreenImageIndex {
                FullscreenImageView2(images: images, descriptions: imageTexts, currentIndex: index, fullscreenImageIndex: $fullscreenImageIndex)
                    .zIndex(2)
            }
        }
    }
    
    @ViewBuilder
    private func contentBox(title: String, description: String, linkURL: String, actionURL: String? = nil) -> some View {
        VStack(alignment: .leading) {
            Text(title)
                .font(.title2)
                .fontWeight(.bold)
                .lineLimit(2)
                .minimumScaleFactor(0.5)
                .foregroundColor(.black)
            
            Divider()
            
            Text(description)
                .font(.subheadline)
                .foregroundColor(.black)
            
            Text("Link")
                .font(.subheadline)
                .foregroundColor(.blue)
                .underline()
                .onTapGesture {
                    if let url = URL(string: linkURL) {
                        UIApplication.shared.open(url)
                    }
                }
        }
        .padding()
        .background(Color.white)
        .cornerRadius(15)
        .shadow(radius: 5)
        .frame(height: 200)
        .padding(.horizontal)
        .onTapGesture {
            if let urlString = actionURL, let url = URL(string: urlString) {
                UIApplication.shared.open(url)
            }
        }
    }
}

struct ViewCDrawingLine {
    var points: [CGPoint]
    var color: Color
}

struct FullscreenImageView2: View {
    let images: [String]
    let descriptions: [String]
    @State var currentIndex: Int
    @Binding var fullscreenImageIndex: Int?
    
    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()
            
            VStack {
                TabView(selection: $currentIndex) {
                    ForEach(0..<images.count, id: \.self) { index in
                        VStack {
                            Image(images[index])
                                .resizable()
                                .scaledToFit()
                                .frame(maxWidth: .infinity, maxHeight: .infinity)
                                .onTapGesture {
                                    withAnimation {
                                        fullscreenImageIndex = nil
                                    }
                                }
                                .padding()
                            
                            ScrollView {
                                Text(descriptions[index])
                                    .padding()
                                    .background(
                                        RoundedRectangle(cornerRadius: 10)
                                            .fill(Color.white)
                                            .overlay(
                                                RoundedRectangle(cornerRadius: 10)
                                                    .stroke(Color.black, lineWidth: 1)
                                            )
                                    )
                                    .padding()
                                    .foregroundColor(.black)
                                    .multilineTextAlignment(.center)
                            }
                            .frame(maxHeight: 150)
                        }
                        .tag(index)
                    }
                }
                .tabViewStyle(PageTabViewStyle())
                .indexViewStyle(PageIndexViewStyle())
                Spacer()
            }
        }
    }
}
struct PopupView3: View {
    @Binding var showPopup: Bool
    let images: [String]
    @Binding var imageTexts: [String]
    @State private var currentPage: Int = 0
    @State private var isFullScreen: Bool = false
    @Binding var fullscreenImageIndex: Int?
    var body: some View {
        VStack(spacing: 20) {
            Text("Was ist an app about apps?")
                .font(.headline)
                .padding()
            
            TabView(selection: $currentPage) {
                ForEach(0..<images.count, id: \.self) { index in
                    VStack {
                        ZStack {
                            Image(images[index])
                                .resizable()
                                .aspectRatio(contentMode: isFullScreen ? .fit : .fill)
                                .frame(width: isFullScreen ? UIScreen.main.bounds.width : 400, height: isFullScreen ? UIScreen.main.bounds.height : 300)
                                .onTapGesture {
                                    withAnimation {
                                        fullscreenImageIndex = index
                                    }
                                }
                            
                            if isFullScreen {
                                VStack {
                                    Spacer()
                                    Text(imageTexts[index])
                                        .font(.body)
                                        .multilineTextAlignment(.center)
                                        .padding()
                                        .background(RoundedRectangle(cornerRadius: 10).fill(Color.white).overlay(RoundedRectangle(cornerRadius: 10).stroke(Color.black, lineWidth: 1)))
                                        .padding()
                                        .foregroundColor(.black)
                                }
                                .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .bottom)
                                .transition(.opacity)
                            }
                        }
                        
                        if !isFullScreen {
                            ScrollView {
                                Text(imageTexts[index])
                                    .font(.body)
                                    .multilineTextAlignment(.center)
                                    .padding()
                                    .background(Color.white)
                                    .cornerRadius(10)
                                    .frame(maxWidth: .infinity, alignment: .center)
                                    .foregroundColor(.black)
                            }
                            .frame(height: 100)
                        }
                    }
                    .tag(index)
                }
            }
            .tabViewStyle(PageTabViewStyle())
            .frame(width: isFullScreen ? UIScreen.main.bounds.width : 600, height: isFullScreen ? UIScreen.main.bounds.height : 400)
            
            Text("\(currentPage + 1) of \(images.count)")
                .font(.footnote)
                .padding(-10)
            
            Button(action: {
                withAnimation {
                    showPopup = false
                }
            }) {
                Image(systemName: "xmark.circle")
                    .font(.title2)
                    .padding()
                    .foregroundColor(.black)
                    .cornerRadius(10)
            }
        }
        .frame(width: isFullScreen ? UIScreen.main.bounds.width : 600, height: isFullScreen ? UIScreen.main.bounds.height : 600)
        .background(Color.white)
        .cornerRadius(20)
        .shadow(radius: 20)
        .padding()
    }
} 
    struct ViewC_Previews: PreviewProvider {
        static var previews: some View {
            ViewC()
        }
    }
