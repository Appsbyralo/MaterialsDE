import UIKit
import MapKit

class MapViewController: UIViewController, MKMapViewDelegate {
    
    var mapView: MKMapView!
    var pin: MKPointAnnotation!
    var initialLocation: CLLocationCoordinate2D
    var regionRadius: CLLocationDistance
    var pinImagesContainer: UIView!
    
    init(initialLocation: CLLocationCoordinate2D, regionRadius: CLLocationDistance) {
        self.initialLocation = initialLocation
        self.regionRadius = regionRadius
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Create and configure the map view
        mapView = MKMapView(frame: view.bounds)
        mapView.delegate = self
        mapView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        view.addSubview(mapView)
        
        // Set initial region to display
        let coordinateRegion = MKCoordinateRegion(center: initialLocation, latitudinalMeters: regionRadius, longitudinalMeters: regionRadius)
        mapView.setRegion(coordinateRegion, animated: true)
        
        // Add gesture recognizer for placing and moving the pin
        let longPressGestureRecognizer = UILongPressGestureRecognizer(target: self, action: #selector(handleLongPress(gestureRecognizer:)))
        mapView.addGestureRecognizer(longPressGestureRecognizer)
        
        // Add zoom buttons
        addZoomButtons()
        
        // Add pin images container
        addPinImagesContainer()
    }
    
    @objc func handleLongPress(gestureRecognizer: UILongPressGestureRecognizer) {
        if gestureRecognizer.state == .began {
            let location = gestureRecognizer.location(in: mapView)
            let coordinate = mapView.convert(location, toCoordinateFrom: mapView)
            
            if pin == nil {
                // Create a new pin
                pin = MKPointAnnotation()
                pin.coordinate = coordinate
                mapView.addAnnotation(pin)
            } else {
                // Move the existing pin
                pin.coordinate = coordinate
            }
        }
    }
    
    private func addZoomButtons() {
        let zoomInButton = UIButton(frame: CGRect(x: view.frame.width - 60, y: view.frame.height - 150, width: 50, height: 50))
        zoomInButton.setTitle("+", for: .normal)
        zoomInButton.backgroundColor = UIColor.systemBlue
        zoomInButton.layer.cornerRadius = 25
        zoomInButton.addTarget(self, action: #selector(zoomIn), for: .touchUpInside)
        view.addSubview(zoomInButton)
        
        let zoomOutButton = UIButton(frame: CGRect(x: view.frame.width - 60, y: view.frame.height - 90, width: 50, height: 50))
        zoomOutButton.setTitle("-", for: .normal)
        zoomOutButton.backgroundColor = UIColor.systemBlue
        zoomOutButton.layer.cornerRadius = 25
        zoomOutButton.addTarget(self, action: #selector(zoomOut), for: .touchUpInside)
        view.addSubview(zoomOutButton)
    }
    
    @objc private func zoomIn() {
        var region = mapView.region
        region.span.latitudeDelta /= 2.0
        region.span.longitudeDelta /= 2.0
        mapView.setRegion(region, animated: true)
    }
    
    @objc private func zoomOut() {
        var region = mapView.region
        region.span.latitudeDelta *= 2.0
        region.span.longitudeDelta *= 2.0
        mapView.setRegion(region, animated: true)
    }
    
    private func addPinImagesContainer() {
        pinImagesContainer = UIView(frame: CGRect(x: 10, y: 50, width: 100, height: 150))
        pinImagesContainer.backgroundColor = UIColor.systemGray4
        pinImagesContainer.layer.cornerRadius = 10
        view.addSubview(pinImagesContainer)
        
        // Add a single pin image centered in the container
        let pinImageView = UIImageView(image: UIImage(systemName: "pin.fill"))
        pinImageView.frame = CGRect(x: (pinImagesContainer.frame.width - 30) / 2, y: (pinImagesContainer.frame.height - 30) / 2, width: 30, height: 30)
        pinImageView.isUserInteractionEnabled = true
        pinImageView.tag = 0 // This tag can be used to reset the position if needed
        let panGestureRecognizer = UIPanGestureRecognizer(target: self, action: #selector(handlePinPan(gestureRecognizer:)))
        pinImageView.addGestureRecognizer(panGestureRecognizer)
        pinImagesContainer.addSubview(pinImageView)
    }
    
    
    @objc private func handlePinPan(gestureRecognizer: UIPanGestureRecognizer) {
        let pinImageView = gestureRecognizer.view!
        let translation = gestureRecognizer.translation(in: view)
        pinImageView.center = CGPoint(x: pinImageView.center.x + translation.x, y: pinImageView.center.y + translation.y)
        gestureRecognizer.setTranslation(.zero, in: view)
        
        if gestureRecognizer.state == .ended {
            let location = gestureRecognizer.location(in: mapView)
            let coordinate = mapView.convert(location, toCoordinateFrom: mapView)
            
            let newPin = MKPointAnnotation()
            newPin.coordinate = coordinate
            mapView.addAnnotation(newPin)
            
            // Recenter the pin image in the container
            pinImageView.center = CGPoint(x: pinImagesContainer.frame.width / 2, y: pinImagesContainer.frame.height / 2)
        }
    }
}
