import SwiftUI

struct ViewC: View {
    var body: some View {
        
        ZStack {
            Color(.blue)
            Text("📒")
                .font(.system(size: 148))
            Text("🍔")
                .font(.system(size: 75))
        }
    }
}

struct ViewC_Previews: PreviewProvider {
    static var previews: some View {
        ViewC()
    }
}

