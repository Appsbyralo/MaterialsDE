import SwiftUI
/*#-code-walkthrough(VC.1)*/
import AVKit
/*#-code-walkthrough(VC.1)*/

struct ViewC: View {
    var body: some View {
        TabView {
            VideoPlayerView()
                .tabItem {
                    Label("ViewC", systemImage: "video")
                }
        }
    }
}

struct VideoPlayerView: View {
    let player = AVPlayer(url: Bundle.main.url(forResource: "Students", withExtension: "mp4")!)
    
    var body: some View {
   
        VideoPlayer(player: player)
        /*#-code-walkthrough(VC.2)*/
            .aspectRatio(contentMode: .fit)
        /*#-code-walkthrough(VC.2)*/
            .onAppear {
                /*#-code-walkthrough(VC.3)*/
                player.volume = 0
                /*#-code-walkthrough(VC.3)*/
                player.play()
              
            }
    }
}

struct ViewC_Previews: PreviewProvider {
    static var previews: some View {
        ViewC()
    }
}

