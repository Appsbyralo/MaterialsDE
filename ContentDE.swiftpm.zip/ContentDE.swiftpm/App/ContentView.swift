import SwiftUI
import PlaygroundSupport

struct ContentView: View {
    var body: some View {
        TabView {
            ViewA()
                .tabItem {
                    Image(systemName: "phone.fill")
                    Text("Foto einfügen")
                }
            ViewB()
                .tabItem {
                    Image(systemName: "eraser.fill")
                    Text("Link einfügen")
                }
            ViewC()
                .tabItem {
                    Image(systemName: "book.fill")
                    Text("Video einfügen")
                }
            ViewD()
                .tabItem {
                    Image(systemName: "photo.on.rectangle")
                    Text("Scroll-Ansicht")
                }
        }
    }
}




